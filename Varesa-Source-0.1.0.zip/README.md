# Varesa

Varesa is a fresh Android app project. This first milestone establishes the native Compose app shell, five-tab navigation, dark/light appearance, and a GitHub Actions debug APK workflow.

## Current status
This is a foundation preview, not a finished content app. The content-provider integrations, real image/video feed, favorites persistence, home-screen widget, AI generation and source attribution pipeline are not connected yet. Settings shown for providers are UI previews only.

## Build
Open this repository in Android Studio or push it to GitHub and run the `Build Varesa APK` workflow from Actions. The debug APK is uploaded as an Actions artifact.

## Planned integrations
Provider integrations will be added individually after checking API access, licensing, attribution requirements and device performance. API keys must be stored outside source control.
