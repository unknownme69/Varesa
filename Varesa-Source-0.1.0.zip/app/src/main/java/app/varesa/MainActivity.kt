package app.varesa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Violet = Color(0xFF9B7BFF)
private val Dark = Color(0xFF101016)
private val Panel = Color(0xFF1B1A25)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VaresaApp() }
    }
}

@Composable
fun VaresaApp() {
    var tab by remember { mutableStateOf("Discover") }
    var darkMode by remember { mutableStateOf(true) }
    val scheme = if (darkMode) darkColorScheme(
        primary = Violet, background = Dark, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    ) else lightColorScheme(primary = Color(0xFF7252D6))
    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    val items = listOf("Discover", "Gallery", "Videos", "Saved", "Settings")
                    val icons = listOf(Icons.Default.Explore, Icons.Default.GridView,
                        Icons.Default.PlayCircle, Icons.Default.Bookmark, Icons.Default.Settings)
                    items.forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = tab == item, onClick = { tab = item },
                            icon = { Icon(icons[i], contentDescription = item) },
                            label = { Text(item, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("V", color = Violet, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(8.dp))
                    Text("VARESA", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        letterSpacing = 3.sp)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Violet)
                }
                Spacer(Modifier.height(18.dp))
                when (tab) {
                    "Discover" -> DiscoverScreen()
                    "Gallery" -> PlaceholderScreen("Your visual universe", "Images from your selected sources will live here.")
                    "Videos" -> PlaceholderScreen("Anime, in motion", "Trailers, edits and memorable scenes will appear here.")
                    "Saved" -> PlaceholderScreen("Your collection", "Save images and videos to build your own collection.")
                    else -> SettingsScreen(darkMode, { darkMode = it })
                }
            }
        }
    }
}

@Composable
fun DiscoverScreen() {
    Text("DISCOVER", color = Violet, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    Spacer(Modifier.height(8.dp))
    Text("Find your next obsession.", fontSize = 27.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    Text("A living feed for anime, fantasy and worlds worth exploring.",
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f))
    Spacer(Modifier.height(20.dp))
    Box(Modifier.fillMaxWidth().height(170.dp)
        .background(brush = androidx.compose.ui.graphics.Brush.linearGradient(
            listOf(Color(0xFF30204F), Color(0xFF171722))), RoundedCornerShape(22.dp))
        .padding(20.dp)) {
        Column(Modifier.align(Alignment.BottomStart)) {
            Text("THE VAresa FEED".uppercase(), color = Violet, fontSize = 11.sp, letterSpacing = 2.sp)
            Text("A universe of visuals.", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Your sources. Your taste. Your world.", color = Color.LightGray, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(20.dp))
    Text("EXPLORE", color = Violet, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 2.sp)
    Spacer(Modifier.height(10.dp))
    listOf("⚔  Action & unforgettable fights", "✨  Overpowered protagonists",
        "🌀  Isekai & other worlds", "🌙  Fantasy, romance & comedy").forEach {
        Card(Modifier.fillMaxWidth().padding(bottom = 9.dp), colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
            Text(it, Modifier.padding(16.dp), fontWeight = FontWeight.Medium)
        }
    }
    Text("Preview build · Content sources are not connected yet",
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = .5f), fontSize = 11.sp)
}

@Composable
fun PlaceholderScreen(title: String, subtitle: String) {
    Spacer(Modifier.height(28.dp))
    Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Text(subtitle, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f))
    Spacer(Modifier.height(24.dp))
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(20.dp)) {
            Icon(Icons.Default.AutoAwesome, tint = Violet, contentDescription = null)
            Spacer(Modifier.height(10.dp))
            Text("Coming together", fontWeight = FontWeight.Bold)
            Text("This section is part of the foundation. Real content integration is the next stage.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
        }
    }
}

@Composable
fun SettingsScreen(darkMode: Boolean, onDarkMode: (Boolean) -> Unit) {
    LazyColumn {
        item {
            Text("Settings", fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Shape your Varesa experience.", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f))
            Spacer(Modifier.height(18.dp))
            SettingSwitch("Dark appearance", "Use the cinematic dark theme.", darkMode, onDarkMode)
            Spacer(Modifier.height(8.dp))
            Text("CONTENT PREFERENCES", color = Violet, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            listOf("YouTube videos", "Anime image sources", "Genshin Impact art (target ~2%)",
                "AI artwork (maximum 25%)", "Source and artist attribution").forEach { label ->
                var enabled by remember { mutableStateOf(label != "AI artwork (maximum 25%)") }
                SettingSwitch(label, "Preference control preview", enabled) { enabled = it }
            }
            Spacer(Modifier.height(12.dp))
            Text("DISCOVERY PROMPTS", color = Violet, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            listOf("anime", "anime fight scenes", "anime edit", "anime best moments", "anime trailer")
                .forEach { Text("•  $it", Modifier.padding(vertical = 5.dp)) }
            Spacer(Modifier.height(16.dp))
            Text("Varesa 0.1.0 · Foundation preview", fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = .5f))
        }
    }
}

@Composable
fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .55f))
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
